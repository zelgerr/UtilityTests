const { test, expect } = require('@playwright/test');

test('WebSocket connection status test', async ({ page }) => {

    await page.goto('http://185.5.199.33:8082/controlls/controls.php');

    // Warte darauf, dass die Seite und WebSocket vollständig geladen sind
    await page.waitForSelector('#status');

    // Überprüfe, ob eine erfolgreiche Verbindung hergestellt wurde
    const isConnected = await page.textContent('#status');
    expect(isConnected).toBe('Connected!');

    // Überprüfe den Status nach der Trennung
    const isDisconnected = await page.textContent('#status');
    expect(isDisconnected).toBe('Disconnected!');
});