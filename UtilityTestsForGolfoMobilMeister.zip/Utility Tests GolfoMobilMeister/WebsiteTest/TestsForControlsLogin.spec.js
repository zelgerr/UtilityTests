// Import Playwright
const { test, expect } = require('@playwright/test');

test.describe('Login functionality tests', () => {
    test.beforeEach(async ({ page }, testInfo) => {
        // Setzt die Basis-URL für deine Website hier
        const baseURL = 'http://185.5.199.33:8082/controlls/controls.php'; // Ersetze <deine-ip> mit der IP deiner Website
        await page.goto(`${baseURL}`);
    });

    test('Correct login redirects to controls.html', async ({ page }) => {
        // Eingabe der korrekten Benutzerdaten
        await page.fill('#username', 'admin');
        await page.fill('#password', '1123');

        // Formular absenden
        await Promise.all([
            page.waitForNavigation(), // Warte auf die Navigation nach der Anmeldung
            page.click('button[type="submit"]') // Klicke auf Anmelden
        ]);

        // Überprüfe, ob die URL nach der Anmeldung korrekt ist
        expect(page.url()).toContain('controls.html');
    });

    test('Incorrect login shows an alert with error message', async ({ page }) => {
        // Eingabe von falschen Benutzerdaten
        await page.fill('#username', 'user');
        await page.fill('#password', 'wrong');

        // Überwachen, ob ein Alert aufgerufen wird
        page.on('dialog', async dialog => {
            expect(dialog.message()).toBe('Falsche Benutzername oder Passwort!');
            await dialog.dismiss(); // Schließe das Alert-Fenster
        });

        // Versuche sich anzumelden und erwarte den Alert
        await page.click('button[type="submit"]');
    });
});
