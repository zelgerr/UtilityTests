const { test, expect } = require('@playwright/test');

test.describe('Website Utility Tests', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto('http://10.10.31.13/Website/Mainpage/Mainpage.php'); // Ändern Sie die URL entsprechend Ihrer Umgebung
    });

    test('Modal für Datenschutzrichtlinien wird angezeigt', async ({ page }) => {
        const modal = await page.locator('#privacy-modal');
        await expect(modal).toBeVisible();
    });

    test('Akzeptieren der Datenschutzrichtlinien', async ({ page }) => {
        await page.click('#accept');
        const modal = await page.locator('#privacy-modal');
        await expect(modal).toBeHidden();
    });

    test('Ablehnen der Datenschutzrichtlinien und Weiterleitung', async ({ page }) => {
        await page.click('#decline');
        await expect(page).toHaveURL('about:blank');
    });

    // TODO: Diesen Test zum laufen bringen
    test('Check if the Get in Touch button scrolls to the bottom of the page', async ({ page }) => {
        // Zuerst die URL deiner Website einfügen, wo der Button vorhanden ist
        await page.goto('http://10.10.31.13/Website/Mainpage/Mainpage.php');

        // Warten, bis der Button vollständig geladen ist
        await page.waitForSelector('#title-button');

        // Klicken auf den Get in Touch Button
        await page.click('#title-button');

        // Warten, dass das Scrollen ausgeführt wird
        await page.waitForFunction(() => window.scrollY > 1000);

        // Scroll-Position nach dem Klick erfassen
        const scrollPositionAfter = await page.evaluate(() => window.scrollY);

        // Überprüfen, ob die Seite nach dem Klicken des Buttons nach unten gescrollt wurde
        expect(scrollPositionAfter).toBeGreaterThan(scrollPositionBefore);
    });
});
