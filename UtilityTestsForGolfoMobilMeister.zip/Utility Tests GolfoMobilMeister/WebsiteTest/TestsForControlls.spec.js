const { test, expect } = require('@playwright/test');

test.describe('WebSocket and button interaction tests', () => {
    test.beforeEach(async ({ page }) => {
        const baseURL = 'http://185.5.199.33:8082/controlls/controls.php'; // Ersetze <deine-ip> mit der IP deiner Website
        await page.goto(baseURL);
    });

    test('WebSocket connection establishes correctly', async ({ page }) => {
        await expect(page.locator('#status')).toHaveText('Connected!');
    });

    test('WebSocket disconnects and shows "Disconnected!"', async ({ page }) => {
        // Hier könntest du simulieren, dass der Server die Verbindung trennt, falls möglich
        await page.evaluate(() => {
            const socket = new WebSocket("ws://10.10.30.132:8765");
            socket.close();
        });
        await expect(page.locator('#status')).toHaveText('Disconnected!');
    });

    test('Pressing "W" button sends the correct data via WebSocket', async ({ page }) => {
        await page.click('button:has-text("W")', { force: true });
        // Überprüfe Logs oder Verhalten des Servers, um zu bestätigen, dass die richtigen Daten gesendet wurden
        // Dies hängt von deiner Server-Implementierung ab und wie du die Tests isolieren kannst
    });

    test('Pressing "D" key sends data', async ({ page }) => {
        await page.keyboard.press('D');
        // Überprüfe Logs oder Verhalten des Servers, um zu bestätigen, dass die richtigen Daten gesendet wurden
        // Dies hängt von deiner Server-Implementierung ab und wie du die Tests isolieren kannst
    });

    test('Toggle camera visibility', async ({ page }) => {
        await page.click('button:has-text("Toggle Cam")');
        const blackDivZIndex = await page.evaluate(() => {
            return document.getElementById("black").style.zIndex;
        });
        expect(blackDivZIndex).toBe('2'); // Überprüfe, ob das schwarze Div nun über dem Video liegt
    });
});

